# Foto AI (Android)

Aplikasi deskripsi foto memakai Gemini API. Dibuat oleh Edymart Kerupuk.

## Fitur
- Simpan kunci API (dienkripsi di perangkat), bisa dihapus lagi
- Tombol **Dapatkan kunci API di Google AI Studio**: membuka aistudio.google.com/apikey di browser HP
- Kolom **Model Gemini** (default: gemini-3.8-flash), bisa diganti tanpa build ulang
- Pilih foto dari galeri atau **bagikan foto dari aplikasi lain** (Galeri, WhatsApp, dll.) langsung ke "Foto AI"; foto otomatis diproses kalau kunci sudah tersimpan
- Tombol **Kamera Belakang**: pratinjau kamera terbuka, hitung mundur 2 detik, foto diambil otomatis lalu langsung dideskripsikan (benda-benda di sekeliling beserta warnanya). Foto kamera tidak disimpan di HP. Ada bunyi jepret saat foto diambil
- Nada tunggu (bip pendek berulang) berbunyi selama Gemini memproses, berhenti saat jawaban muncul
- Tombol **Deskripsikan Foto**; hasilnya tampil di kotak "Deskripsi foto" sendiri
- **Tanya jawab** selalu aktif; jawabannya tampil di kotak terpisah di bawahnya, jadi deskripsi awal tidak tertimpa
- Hasil deskripsi dan tanya jawab otomatis kosong tiap aplikasi dibuka dari awal

## Build & pasang lewat GitHub
1. Upload semua isi folder ini ke repo GitHub (termasuk folder `.github` dan file `app/fotoai.keystore`).
2. Tiap push, workflow **Build APK** membuat APK dan satu **Release** baru (tab Releases di repo), mis. `v1.1.7`.
3. Download APK dari Release itu dan pasang di HP.

## Pembaruan antar versi
- APK baru langsung menimpa versi lama (data dan kunci API tetap), asalkan:
  - `app/fotoai.keystore` tidak pernah diganti (tanda tangan harus sama), dan
  - versi baru lebih baru dari yang terpasang (otomatis, nomor versi dihitung dari waktu build).
- Android tidak mengizinkan memasang versi **lebih lama** di atas yang baru. Untuk kembali ke versi lama, hapus aplikasi dulu lalu pasang APK lama dari Releases (kunci API perlu diisi lagi).
- Kunci tanda tangan ada di repo (cukup untuk pemakaian pribadi). Kalau suatu saat mau rilis ke Play Store, buat kunci baru yang dirahasiakan.

## Android Studio
Buka folder ini, tunggu Gradle sync, lalu Run.
Kunci API diambil di https://aistudio.google.com/apikey.
