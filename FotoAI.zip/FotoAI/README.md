# Foto AI (Android)

Aplikasi deskripsi foto memakai Gemini API.

## Fitur
- Simpan kunci API (dienkripsi di perangkat), bisa dihapus lagi
- Pilih foto dari galeri atau **bagikan foto dari aplikasi lain** (Galeri, WhatsApp, dll.) langsung ke "Foto AI"; foto otomatis diproses kalau kunci sudah tersimpan
- Tombol **Deskripsikan Foto**
- **Tanya jawab** selalu aktif: tanya apa saja soal foto, percakapan berlanjut

## Cara pakai
1. Buka folder ini di Android Studio (versi terbaru), tunggu Gradle sync selesai.
2. Colok HP (debugging USB aktif) atau pakai emulator, tekan Run.
3. Ambil kunci API di https://aistudio.google.com/apikey, tempel di aplikasi, tekan **Simpan Kunci API**.
4. Untuk bikin file APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Catatan
- Model Gemini bisa diganti dari kolom "Model Gemini" di aplikasi (default: gemini-3.8-flash), tanpa build ulang.
- Foto diperkecil (maks ~2048 px) sebelum dikirim supaya hemat kuota dan cepat.
- Aplikasi butuh internet.
