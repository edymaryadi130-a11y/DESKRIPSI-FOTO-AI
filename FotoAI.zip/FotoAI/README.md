# DESKRIPSI FOTO AI (Android)

Aplikasi deskripsi foto memakai Gemini API. Dibuat oleh Edymart Kerupuk (namanya juga tampil di layar utama dan di Pengaturan).

## Fitur
- Tombol **Pengaturan** di layar utama membuka layar sendiri yang berisi:
  - **Kunci API Gemini**: simpan (dienkripsi di perangkat) dan hapus
  - **Dapatkan kunci API di Google AI Studio**: membuka aistudio.google.com/apikey di browser HP
  - **Model Gemini**: daftar model berurutan (awal: gemini-3.6-flash, gemini-3.5-flash-lite, gemini-3.1-flash-lite, gemini-3.8-flash). Model terpilih (awal: gemini-3.6-flash) dipakai lebih dulu; kalau gagal atau kuotanya habis, aplikasi otomatis lanjut ke model berikutnya di daftar. **+ Ketik Nama Model Baru** menambah model di urutan paling akhir, tombol **Hapus Model** menghapus model yang sedang dipilih (minimal satu tersisa)
  - **Saran** dan **Donasi**: membuka chat WhatsApp pembuat (0856-8928-050) dengan pesan awal yang sudah terisi
  - **oleh Edymart Kerupuk**, nomor **versi**, dan tombol **Kembali**
- Layar utama tidak menampilkan bilah judul (tulisan nama aplikasi); nama aplikasi hanya tampil di bawah ikon dan di menu Bagikan
- Tombol **Keluar Aplikasi** di paling bawah layar utama menutup aplikasi sepenuhnya
- Selama kunci API belum diisi, layar utama menampilkan petunjuk untuk membuka Pengaturan
- Pilih foto dari galeri atau **bagikan foto dari aplikasi lain** (Galeri, WhatsApp, dll.) langsung ke "DESKRIPSI FOTO AI"; foto otomatis diproses kalau kunci sudah tersimpan
- Tombol **Kamera Belakang**: pratinjau kamera terbuka, hitung mundur 2 detik, foto diambil otomatis lalu langsung dideskripsikan (benda-benda di sekeliling beserta warnanya). Foto kamera tidak disimpan di HP. 
- Tombol **Kamera Uang Rupiah**: cara kerjanya sama dengan Kamera Belakang (hitung mundur 2 detik, foto otomatis), tetapi aplikasi mengenali uang rupiah (kertas atau koin) dan hanya menyebut nilainya, mis. "Lima puluh ribu rupiah". Tetap terbaca kalau uangnya terbalik atau miring; kalau ada beberapa lembar, disebut tiap nilai dan totalnya
- Suara: **jepret** bawaan Android saat foto kamera diambil, **nada tunggu** (bip pendek berulang, volume 92) selama Gemini memproses, dan **nada berhasil** (dering naik) saat jawaban muncul. Volume nada tunggu dan nada berhasil bisa diubah di `MainActivity.kt` (`WAIT_TONE_VOLUME`, `TING_VOLUME`); file suara berhasil ada di `app/src/main/res/raw/ting.wav`
- Hasil deskripsi dan jawaban ditampilkan sebagai teks biasa tanpa tanda bintang (*); kalau dijawab model cadangan, ada keterangan di bawah jawabannya
- Tombol **Deskripsikan Foto**; hasilnya tampil di kotak "Deskripsi foto" sendiri
- **Tanya jawab** selalu aktif; jawabannya tampil di kotak terpisah di bawahnya, jadi deskripsi awal tidak tertimpa
- Hasil deskripsi dan tanya jawab otomatis kosong tiap aplikasi dibuka dari awal

## Build & pasang lewat GitHub
1. Upload semua isi folder ini ke repo GitHub (termasuk folder `.github` dan file `app/fotoai.keystore`).
2. Tiap push, workflow **Build APK** membuat APK dan satu **Release** baru (tab Releases di repo), mis. `v1.1.7`.
3. Download APK dari Release itu dan pasang di HP.

## Pembaruan antar versi
- APK baru langsung menimpa versi lama (data dan kunci API tetap), asalkan:
  - `app/fotoai.keystore` tidak pernah diganti (tanda tangan harus sama), dan
  - versi baru lebih baru dari yang terpasang (otomatis, nomor versi dihitung dari waktu build).
- Android tidak mengizinkan memasang versi **lebih lama** di atas yang baru. Untuk kembali ke versi lama, hapus aplikasi dulu lalu pasang APK lama dari Releases (kunci API perlu diisi lagi).
- Kunci tanda tangan ada di repo (cukup untuk pemakaian pribadi). Kalau suatu saat mau rilis ke Play Store, buat kunci baru yang dirahasiakan.

## Android Studio
Buka folder ini, tunggu Gradle sync, lalu Run.
Kunci API diambil di https://aistudio.google.com/apikey.
