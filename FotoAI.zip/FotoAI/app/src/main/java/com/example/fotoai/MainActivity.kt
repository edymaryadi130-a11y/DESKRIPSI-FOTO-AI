package com.example.fotoai

import android.Manifest
import android.text.InputType
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import android.media.AudioManager
import android.media.MediaActionSound
import android.media.ToneGenerator
import android.content.Intent
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import java.io.File
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.view.inputmethod.InputMethodManager
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private lateinit var tvKeyHint: TextView
    private lateinit var imgPreview: ImageView
    private lateinit var etQuestion: EditText
    private lateinit var scroll: ScrollView
    private lateinit var progress: ProgressBar
    private lateinit var tvDescTitle: TextView
    private lateinit var tvDescription: TextView
    private lateinit var tvQa: TextView
    private lateinit var btnCamera: Button
    private lateinit var cameraBox: View
    private lateinit var previewView: PreviewView
    private lateinit var tvCountdown: TextView
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraJob: Job? = null
    private var waitJob: Job? = null
    private val shutter = MediaActionSound()
    private lateinit var btnDescribe: Button
    private lateinit var btnAsk: Button

    private var imageBase64: String? = null
    private var conversation = JSONArray()
    private var busy = false

    private val picker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadImage(uri, autoDescribe = false)
        }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else Toast.makeText(this, "Izin kamera ditolak. Aktifkan di Pengaturan > Aplikasi.", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs.create(this)
        shutter.load(MediaActionSound.SHUTTER_CLICK)

        tvKeyHint = findViewById(R.id.tvKeyHint)
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        imgPreview = findViewById(R.id.imgPreview)
        etQuestion = findViewById(R.id.etQuestion)
        scroll = findViewById(R.id.scroll)
        progress = findViewById(R.id.progress)
        tvDescTitle = findViewById(R.id.tvDescTitle)
        tvDescription = findViewById(R.id.tvDescription)
        tvQa = findViewById(R.id.tvQa)
        btnDescribe = findViewById(R.id.btnDescribe)

        // Setiap aplikasi dibuka dari awal, hasil deskripsi dan tanya jawab selalu kosong
        // (kotak hasil tidak ikut disimpan sistem: android:saveEnabled="false")
        clearResults()

        btnAsk = findViewById(R.id.btnAsk)
        btnCamera = findViewById(R.id.btnCamera)
        cameraBox = findViewById(R.id.cameraBox)
        previewView = findViewById(R.id.previewView)
        tvCountdown = findViewById(R.id.tvCountdown)
        btnCamera.setOnClickListener { onCameraClicked() }
        findViewById<Button>(R.id.btnCancelCamera).setOnClickListener { closeCamera() }

        findViewById<Button>(R.id.btnPick).setOnClickListener { picker.launch("image/*") }
        btnDescribe.setOnClickListener { describe() }
        btnAsk.setOnClickListener { ask() }

        etQuestion.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                ask(); true
            } else false
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // ---------- Kunci API & model (diatur di layar Pengaturan) ----------

    private fun savedKey(): String = prefs.getString("api_key", "").orEmpty()

    private fun savedModel(): String =
        GeminiClient.normalizeModel(prefs.getString("model", null).orEmpty())

    override fun onResume() {
        super.onResume()
        // Petunjuk muncul selama kunci API belum diisi di Pengaturan
        tvKeyHint.visibility = if (savedKey().isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- Foto ----------

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("image/") == true) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                i.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            if (uri != null) loadImage(uri, autoDescribe = true)
        }
    }

    private fun loadImage(uri: Uri, autoDescribe: Boolean, scene: Boolean = false) {
        setBusy(true)
        lifecycleScope.launch {
            try {
                val (bmp, b64) = withContext(Dispatchers.IO) {
                    val bitmap = decode(uri)
                    val out = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
                    // Foto sementara dari kamera tidak disimpan, hapus setelah dibaca
                    if (uri.scheme == "file") uri.path?.let { File(it).delete() }
                    bitmap to Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                }
                imgPreview.setImageBitmap(bmp)
                imageBase64 = b64
                conversation = JSONArray()
                clearResults()
                setBusy(false)
                if (autoDescribe) {
                    if (savedKey().isEmpty()) {
                        showDescription("Foto diterima. Simpan kunci API dulu di Pengaturan, lalu tekan \"Deskripsikan Foto\".")
                    } else {
                        describe(scene)
                    }
                }
            } catch (e: Exception) {
                setBusy(false)
                showDescription("Gagal membuka foto: ${e.message}")
            }
        }
    }

    // ---------- Tampilan hasil ----------

    private fun clearResults() {
        tvDescTitle.visibility = View.GONE
        tvDescription.visibility = View.GONE
        tvDescription.text = ""
        tvQa.text = ""
    }

    /** Kotak deskripsi: diganti (bukan ditambah) tiap kali deskripsi baru datang. */
    private fun showDescription(text: String) {
        tvDescTitle.visibility = View.VISIBLE
        tvDescription.visibility = View.VISIBLE
        tvDescription.text = text
    }

    private fun decode(uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw IOException("Foto tidak bisa dibaca")

        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    // ---------- Panggilan ke Gemini ----------

    private fun describe(scene: Boolean = false) {
        val prompt = if (scene) {
            "Ini foto dari kamera, menunjukkan keadaan di sekeliling. Sebutkan semua benda yang " +
                "terlihat, lengkap dengan warna masing-masing benda, dalam bentuk daftar " +
                "\"benda: warna\". Setelah itu beri satu kalimat ringkasan suasana sekitar."
        } else {
            "Deskripsikan foto ini secara detail: objek utama, suasana, warna, dan teks yang terlihat."
        }
        send(prompt, showQuestion = false)
    }

    // ---------- Kamera belakang: foto otomatis setelah 2 detik ----------

    private fun onCameraClicked() {
        if (busy || cameraJob != null || cameraBox.visibility == View.VISIBLE) return
        if (savedKey().isEmpty()) {
            Toast.makeText(this, "Simpan kunci API dulu di Pengaturan", Toast.LENGTH_SHORT).show()
            return
        }
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) startCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        cameraBox.visibility = View.VISIBLE
        imgPreview.visibility = View.GONE
        btnCamera.isEnabled = false
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                imageCapture = capture
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                startCountdown()
            } catch (e: Exception) {
                closeCamera()
                showDescription("Kamera gagal dibuka: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startCountdown() {
        cameraJob = lifecycleScope.launch {
            for (n in 2 downTo 1) {
                tvCountdown.text = n.toString()
                delay(1000)
            }
            tvCountdown.text = ""
            takePhoto()
        }
    }

    private fun takePhoto() {
        val capture = imageCapture
        if (capture == null) {
            closeCamera()
            return
        }
        val file = File(cacheDir, "kamera_${System.currentTimeMillis()}.jpg")
        shutter.play(MediaActionSound.SHUTTER_CLICK) // bunyi jepret
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    closeCamera()
                    loadImage(Uri.fromFile(file), autoDescribe = true, scene = true)
                }

                override fun onError(exception: ImageCaptureException) {
                    closeCamera()
                    showDescription("Gagal mengambil foto: ${exception.message}")
                }
            }
        )
    }

    private fun closeCamera() {
        cameraJob?.cancel()
        cameraJob = null
        cameraProvider?.unbindAll()
        imageCapture = null
        tvCountdown.text = ""
        cameraBox.visibility = View.GONE
        imgPreview.visibility = View.VISIBLE
        btnCamera.isEnabled = true
    }

    // ---------- Nada tunggu saat memproses ----------

    /** Bip pendek tiap 1,5 detik selama Gemini memproses; berhenti saat jawaban datang. */
    private fun startWaitTone() {
        stopWaitTone()
        waitJob = lifecycleScope.launch {
            val tg = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 50)
            } catch (e: Exception) {
                null
            } ?: return@launch
            try {
                while (true) {
                    tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
                    delay(1500)
                }
            } finally {
                tg.release()
            }
        }
    }

    private fun stopWaitTone() {
        waitJob?.cancel()
        waitJob = null
    }

    override fun onDestroy() {
        stopWaitTone()
        shutter.release()
        super.onDestroy()
    }

    override fun onStop() {
        super.onStop()
        stopWaitTone() // jangan berbunyi saat aplikasi di latar belakang
        // Kamera dimatikan kalau aplikasi ditinggalkan, supaya tidak jalan di latar belakang
        if (cameraBox.visibility == View.VISIBLE) closeCamera()
    }

    private fun ask() {
        val q = etQuestion.text.toString().trim()
        if (q.isEmpty()) {
            Toast.makeText(this, "Tulis pertanyaannya dulu", Toast.LENGTH_SHORT).show()
            return
        }
        etQuestion.setText("")
        send(q, showQuestion = true)
    }

    private fun send(prompt: String, showQuestion: Boolean) {
        if (busy) return
        val key = savedKey()
        if (key.isEmpty()) {
            Toast.makeText(this, "Simpan kunci API dulu di Pengaturan", Toast.LENGTH_SHORT).show()
            return
        }
        val image = imageBase64
        if (image == null) {
            Toast.makeText(this, "Pilih atau bagikan foto dulu", Toast.LENGTH_SHORT).show()
            return
        }

        // Gambar dilampirkan hanya di giliran pertama; sisanya teks saja
        val turn = GeminiClient.userTurn(prompt, if (conversation.length() == 0) image else null)
        val request = JSONArray()
        for (i in 0 until conversation.length()) request.put(conversation.get(i))
        request.put(turn)

        val model = savedModel()

        // Tutup keyboard dan tampilkan status supaya jelas pertanyaan sedang diproses
        currentFocus?.let {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(it.windowToken, 0)
        }
        Toast.makeText(this, "Memproses…", Toast.LENGTH_SHORT).show()

        setBusy(true)
        startWaitTone()
        lifecycleScope.launch {
            try {
                val answer = GeminiClient.generate(key, model, request)
                conversation.put(turn)
                conversation.put(GeminiClient.modelTurn(answer))
                if (showQuestion) appendQa("Tanya: $prompt\n\n$answer") else showDescription(answer)
            } catch (e: Exception) {
                val msg = "⚠ ${e.message ?: "Terjadi kesalahan"}"
                if (showQuestion) appendQa(msg) else showDescription(msg)
            } finally {
                stopWaitTone()
                setBusy(false)
            }
        }
    }

    /**
     * Tambahkan blok tanya jawab di kotak sendiri (deskripsi di atasnya tidak tersentuh).
     * Layar hanya digulung ke bawah kalau awal blok baru belum kelihatan, tidak pernah ke atas.
     */
    private fun appendQa(block: String) {
        val start = if (tvQa.text.isNotEmpty()) {
            tvQa.append("\n\n")
            tvQa.text.length
        } else 0
        tvQa.append(block)
        tvQa.post {
            val layout = tvQa.layout ?: return@post
            val line = layout.getLineForOffset(start.coerceAtMost(tvQa.text.length))
            val target = tvQa.top + layout.getLineTop(line)
            val visibleBottom = scroll.scrollY + scroll.height
            if (target < scroll.scrollY || target > visibleBottom - scroll.height / 3) {
                scroll.smoothScrollTo(0, maxOf(scroll.scrollY, target - scroll.height / 3))
            }
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        progress.visibility = if (value) View.VISIBLE else View.GONE
        btnDescribe.isEnabled = !value
        btnAsk.isEnabled = !value
        if (cameraBox.visibility != View.VISIBLE) btnCamera.isEnabled = !value
    }
}
