package com.example.fotoai

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private lateinit var etApiKey: EditText
    private lateinit var tvKeyStatus: TextView
    private lateinit var etModel: EditText
    private lateinit var imgPreview: ImageView
    private lateinit var swQa: SwitchMaterial
    private lateinit var qaBox: View
    private lateinit var etQuestion: EditText
    private lateinit var progress: ProgressBar
    private lateinit var tvResult: TextView
    private lateinit var btnDescribe: Button
    private lateinit var btnAsk: Button

    private var imageBase64: String? = null
    private var conversation = JSONArray()
    private var busy = false

    private val picker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadImage(uri, autoDescribe = false)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = createPrefs()

        etApiKey = findViewById(R.id.etApiKey)
        tvKeyStatus = findViewById(R.id.tvKeyStatus)
        etModel = findViewById(R.id.etModel)
        etModel.setText(savedModel())
        findViewById<Button>(R.id.btnSaveModel).setOnClickListener {
            val m = currentModel()
            prefs.edit().putString("model", m).apply()
            etModel.setText(m)
            Toast.makeText(this, "Model tersimpan: $m", Toast.LENGTH_SHORT).show()
        }
        imgPreview = findViewById(R.id.imgPreview)
        swQa = findViewById(R.id.swQa)
        qaBox = findViewById(R.id.qaBox)
        etQuestion = findViewById(R.id.etQuestion)
        progress = findViewById(R.id.progress)
        tvResult = findViewById(R.id.tvResult)
        btnDescribe = findViewById(R.id.btnDescribe)
        btnAsk = findViewById(R.id.btnAsk)

        findViewById<Button>(R.id.btnSaveKey).setOnClickListener { saveKey() }
        findViewById<Button>(R.id.btnDeleteKey).setOnClickListener { deleteKey() }
        findViewById<Button>(R.id.btnPick).setOnClickListener { picker.launch("image/*") }
        btnDescribe.setOnClickListener { describe() }
        btnAsk.setOnClickListener { ask() }

        swQa.setOnCheckedChangeListener { _, checked ->
            qaBox.visibility = if (checked) View.VISIBLE else View.GONE
        }
        etQuestion.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                ask(); true
            } else false
        }

        refreshKeyStatus()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // ---------- Penyimpanan kunci API (terenkripsi) ----------

    private fun createPrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            this,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun savedKey(): String = prefs.getString("api_key", "").orEmpty()

    private fun savedModel(): String =
        prefs.getString("model", null)?.takeIf { it.isNotBlank() } ?: GeminiClient.DEFAULT_MODEL

    /** Isi kolom model (tanpa awalan "models/"); kalau kosong pakai model bawaan. */
    private fun currentModel(): String =
        etModel.text.toString().trim().removePrefix("models/")
            .ifEmpty { GeminiClient.DEFAULT_MODEL }

    private fun saveKey() {
        val key = etApiKey.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Kunci API masih kosong", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putString("api_key", key).apply()
        etApiKey.setText("")
        refreshKeyStatus()
        Toast.makeText(this, "Kunci API tersimpan", Toast.LENGTH_SHORT).show()
    }

    private fun deleteKey() {
        prefs.edit().remove("api_key").apply()
        refreshKeyStatus()
        Toast.makeText(this, "Kunci API dihapus", Toast.LENGTH_SHORT).show()
    }

    private fun refreshKeyStatus() {
        val key = savedKey()
        tvKeyStatus.text = if (key.isEmpty()) {
            "Belum ada kunci API tersimpan."
        } else {
            "Kunci tersimpan: …${key.takeLast(4)}"
        }
    }

    // ---------- Foto ----------

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("image/") == true) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                i.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            if (uri != null) loadImage(uri, autoDescribe = true)
        }
    }

    private fun loadImage(uri: Uri, autoDescribe: Boolean) {
        setBusy(true)
        lifecycleScope.launch {
            try {
                val (bmp, b64) = withContext(Dispatchers.IO) {
                    val bitmap = decode(uri)
                    val out = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
                    bitmap to Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                }
                imgPreview.setImageBitmap(bmp)
                imageBase64 = b64
                conversation = JSONArray()
                tvResult.text = ""
                setBusy(false)
                if (autoDescribe) {
                    if (savedKey().isEmpty()) {
                        tvResult.text = "Foto diterima. Simpan kunci API dulu, lalu tekan \"Deskripsikan Foto\"."
                    } else {
                        describe()
                    }
                }
            } catch (e: Exception) {
                setBusy(false)
                tvResult.text = "Gagal membuka foto: ${e.message}"
            }
        }
    }

    private fun decode(uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw IOException("Foto tidak bisa dibaca")

        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    // ---------- Panggilan ke Gemini ----------

    private fun describe() {
        send("Deskripsikan foto ini secara detail: objek utama, suasana, warna, dan teks yang terlihat.", showQuestion = false)
    }

    private fun ask() {
        val q = etQuestion.text.toString().trim()
        if (q.isEmpty()) {
            Toast.makeText(this, "Tulis pertanyaannya dulu", Toast.LENGTH_SHORT).show()
            return
        }
        etQuestion.setText("")
        send(q, showQuestion = true)
    }

    private fun send(prompt: String, showQuestion: Boolean) {
        if (busy) return
        val key = savedKey()
        if (key.isEmpty()) {
            Toast.makeText(this, "Simpan kunci API dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val image = imageBase64
        if (image == null) {
            Toast.makeText(this, "Pilih atau bagikan foto dulu", Toast.LENGTH_SHORT).show()
            return
        }

        // Gambar dilampirkan hanya di giliran pertama; sisanya teks saja
        val turn = GeminiClient.userTurn(prompt, if (conversation.length() == 0) image else null)
        val request = JSONArray()
        for (i in 0 until conversation.length()) request.put(conversation.get(i))
        request.put(turn)

        val model = currentModel()
        prefs.edit().putString("model", model).apply()

        setBusy(true)
        lifecycleScope.launch {
            try {
                val answer = GeminiClient.generate(key, model, request)
                conversation.put(turn)
                conversation.put(GeminiClient.modelTurn(answer))
                val block = buildString {
                    if (tvResult.text.isNotEmpty()) append("\n\n")
                    if (showQuestion) append("Tanya: $prompt\n\n")
                    append(answer)
                }
                tvResult.append(block)
            } catch (e: Exception) {
                val msg = e.message ?: "Terjadi kesalahan"
                tvResult.append((if (tvResult.text.isNotEmpty()) "\n\n" else "") + "⚠ $msg")
            } finally {
                setBusy(false)
            }
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        progress.visibility = if (value) View.VISIBLE else View.GONE
        btnDescribe.isEnabled = !value
        btnAsk.isEnabled = !value
    }
}
