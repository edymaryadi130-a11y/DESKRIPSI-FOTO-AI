package com.example.fotoai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    // Model utama bawaan; daftar dan urutan cadangan diatur di Pengaturan
    const val DEFAULT_MODEL = "gemini-3.6-flash"

    private const val SYSTEM_PROMPT =
        "Kamu asisten yang menjelaskan isi foto. Jawab selalu dalam bahasa Indonesia, " +
            "jelas dan ringkas. Kalau ada teks di foto, sebutkan juga. Tulis dengan teks biasa: " +
            "jangan memakai tanda bintang (*), pagar (#), atau format markdown. " +
            "Untuk daftar, pakai tanda hubung (-) atau nomor."

    /** Satu giliran percakapan. Gambar hanya dilampirkan di giliran pertama. */
    fun userTurn(text: String, imageBase64: String? = null): JSONObject {
        val parts = JSONArray().put(JSONObject().put("text", text))
        if (imageBase64 != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", imageBase64)
                )
            )
        }
        return JSONObject().put("role", "user").put("parts", parts)
    }

    fun modelTurn(text: String): JSONObject =
        JSONObject().put("role", "model")
            .put("parts", JSONArray().put(JSONObject().put("text", text)))

    /**
     * Rapikan nama model: huruf kecil, spasi jadi "-", buang awalan "models/"
     * dan karakter yang tidak boleh ada di nama model.
     */
    fun normalizeModel(raw: String): String {
        val cleaned = raw.trim().lowercase()
            .removePrefix("models/")
            .replace(Regex("\\s+"), "-")
            .replace(Regex("[^a-z0-9.\\-_]"), "")
        return cleaned.ifEmpty { DEFAULT_MODEL }
    }

    /** Buang tanda bintang dari hasil: "* butir" jadi "- butir", sisanya (tebal/miring) dihapus. */
    fun cleanText(raw: String): String =
        raw.lines()
            .joinToString("\n") { it.replace(Regex("^(\\s*)\\*\\s+"), "$1- ") }
            .replace("*", "")

    /** Kesalahan dari server Gemini beserta kode HTTP-nya. */
    class GeminiException(val code: Int, message: String) : IOException(message) {
        /** Model lain layak dicoba kalau masalahnya bukan kunci API (kuota habis, model tidak ada, server sibuk). */
        val canFallback: Boolean
            get() = code != 401 && !message.orEmpty().contains("api key", ignoreCase = true)
    }

    /**
     * Coba model satu per satu sesuai urutan. Kalau sebuah model gagal / kuota habis, lanjut ke
     * model berikutnya. Hasilnya: (jawaban, model yang akhirnya menjawab).
     */
    suspend fun generateWithFallback(
        apiKey: String,
        models: List<String>,
        contents: JSONArray,
        onSwitch: (String) -> Unit = {}
    ): Pair<String, String> {
        var lastError: GeminiException? = null
        for ((i, m) in models.withIndex()) {
            if (i > 0) onSwitch(m)
            try {
                return generate(apiKey, m, contents) to m
            } catch (e: GeminiException) {
                if (!e.canFallback) throw e
                lastError = e
            }
        }
        throw IOException(
            "Semua model sudah dicoba (${models.joinToString(", ")}), semuanya gagal atau kuotanya habis. " +
                "Kesalahan terakhir: ${lastError?.message}"
        )
    }

    suspend fun generate(apiKey: String, model: String, contents: JSONArray): String =
        withContext(Dispatchers.IO) {
            val modelName = normalizeModel(model)
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30_000
                readTimeout = 180_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            try {
                val body = JSONObject()
                    .put("contents", contents)
                    .put(
                        "systemInstruction",
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))
                        )
                    )
                    .toString()

                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                if (code !in 200..299) {
                    val msg = try {
                        JSONObject(text).getJSONObject("error").getString("message")
                    } catch (e: Exception) {
                        text.take(300)
                    }
                    throw GeminiException(code, "Gagal ($code) dengan model \"$modelName\": $msg")
                }

                val root = JSONObject(text)
                val candidates = root.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    val reason = root.optJSONObject("promptFeedback")?.optString("blockReason")
                    throw IOException(
                        if (!reason.isNullOrEmpty()) "Permintaan diblokir: $reason"
                        else "Gemini tidak memberi jawaban."
                    )
                }
                val parts = candidates.getJSONObject(0)
                    .optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        sb.append(parts.getJSONObject(i).optString("text"))
                    }
                }
                cleanText(sb.toString().trim()).ifEmpty { throw IOException("Jawaban kosong dari Gemini.") }
            } catch (e: java.net.SocketTimeoutException) {
                throw IOException(
                    "Waktu habis: tidak ada balasan dari Gemini. Bisa karena sinyal lambat atau " +
                        "server sedang sibuk. Coba kirim lagi."
                )
            } catch (e: java.net.UnknownHostException) {
                throw IOException("Tidak ada koneksi internet.")
            } finally {
                conn.disconnect()
            }
        }
}
