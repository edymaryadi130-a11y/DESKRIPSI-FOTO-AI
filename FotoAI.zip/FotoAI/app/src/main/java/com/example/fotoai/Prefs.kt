package com.example.fotoai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Penyimpanan terenkripsi (kunci API, model) yang dipakai bersama layar utama dan Pengaturan. */
object Prefs {

    /** Urutan model: yang pertama dipakai dulu, kalau gagal / kuota habis lanjut ke berikutnya. */
    val DEFAULT_MODELS = listOf(
        "gemini-3.6-flash",
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-3.8-flash"
    )

    // Model yang pernah ada di daftar lama dan sudah dihapus atas permintaan pengguna
    private val DROPPED = setOf("gemini-3.5-flash", "gemini-2.5-pro", "gemini-2.0-flash", "gemini-2.5-flash")

    /** Daftar model tersimpan (urutan = urutan cadangan). Pertama kali: daftar awal + ketikan lama. */
    fun loadModelList(p: SharedPreferences): MutableList<String> {
        val saved = p.getString("model_list_v2", null)
        if (saved != null) {
            val list = saved.split("\n").filter { it.isNotBlank() }.toMutableList()
            if (list.isNotEmpty()) return list
        }
        val list = DEFAULT_MODELS.toMutableList()
        val old = p.getString("model_list", null)?.split("\n").orEmpty() +
            p.getStringSet("custom_models", emptySet()).orEmpty().sorted()
        old.filter { it.isNotBlank() && it !in list && it !in DROPPED }.forEach { list.add(it) }
        saveModelList(p, list)
        p.edit().putString("model", list.first()).apply() // model utama kembali ke yang pertama
        return list
    }

    fun saveModelList(p: SharedPreferences, list: List<String>) {
        p.edit().putString("model_list_v2", list.joinToString("\n")).apply()
    }

    /** Model terpilih dulu, lalu model sesudahnya di daftar, lalu yang di atasnya (berputar). */
    fun modelChain(p: SharedPreferences): List<String> {
        val list = loadModelList(p)
        val saved = GeminiClient.normalizeModel(p.getString("model", null).orEmpty())
        val start = list.indexOf(saved).takeIf { it >= 0 } ?: 0
        return list.drop(start) + list.take(start)
    }
    fun create(context: Context): SharedPreferences {
        val app = context.applicationContext
        val masterKey = MasterKey.Builder(app)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            app,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
}
