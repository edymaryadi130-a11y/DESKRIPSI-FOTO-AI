package com.example.fotoai

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Layar Pengaturan: kunci API, model Gemini, saran/donasi, pembuat dan versi. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var etApiKey: EditText
    private lateinit var tvKeyStatus: TextView
    private lateinit var spModel: Spinner
    private var modelList = mutableListOf<String>()
    private var selectedModel = GeminiClient.DEFAULT_MODEL

    private val builtinModels = listOf(
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite",
        "gemini-2.5-pro",
        "gemini-2.0-flash"
    )
    private val addModelLabel = "+ Ketik Nama Model Baru"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = Prefs.create(this)

        etApiKey = findViewById(R.id.etApiKey)
        tvKeyStatus = findViewById(R.id.tvKeyStatus)
        spModel = findViewById(R.id.spModel)

        findViewById<Button>(R.id.btnSaveKey).setOnClickListener { saveKey() }
        findViewById<Button>(R.id.btnDeleteKey).setOnClickListener { deleteKey() }
        findViewById<Button>(R.id.btnGetKey).setOnClickListener { openAiStudio() }
        findViewById<Button>(R.id.btnSaran).setOnClickListener {
            openWhatsApp("Halo Edymart Kerupuk, saya pengguna Deskripsi Foto AI. Saya ingin memberi saran: ")
        }
        findViewById<Button>(R.id.btnDonasi).setOnClickListener {
            openWhatsApp("Halo Edymart Kerupuk, saya pengguna Deskripsi Foto AI dan ingin berdonasi. Bagaimana caranya?")
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<TextView>(R.id.tvAuthor).text = "oleh Edymart Kerupuk"
        findViewById<TextView>(R.id.tvVersion).text = "Versi ${appVersion()}"

        setupModelSpinner()
        refreshKeyStatus()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    // ---------- Kunci API ----------

    private fun savedKey(): String = prefs.getString("api_key", "").orEmpty()

    private fun saveKey() {
        val key = etApiKey.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Kunci API masih kosong", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putString("api_key", key).apply()
        etApiKey.setText("")
        refreshKeyStatus()
        Toast.makeText(this, "Kunci API tersimpan", Toast.LENGTH_SHORT).show()
    }

    private fun deleteKey() {
        prefs.edit().remove("api_key").apply()
        refreshKeyStatus()
        Toast.makeText(this, "Kunci API dihapus", Toast.LENGTH_SHORT).show()
    }

    private fun refreshKeyStatus() {
        val key = savedKey()
        tvKeyStatus.text = if (key.isEmpty()) {
            "Belum ada kunci API tersimpan."
        } else {
            "Kunci tersimpan: …${key.takeLast(4)}"
        }
    }

    /** Buka halaman Google AI Studio untuk membuat kunci API (di browser HP). */
    private fun openAiStudio() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Browser tidak ditemukan. Buka aistudio.google.com/apikey secara manual.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ---------- Pilihan model Gemini ----------

    private fun setupModelSpinner() {
        selectedModel = GeminiClient.normalizeModel(prefs.getString("model", null).orEmpty())
        refreshModelSpinner()
        spModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (pos >= modelList.size) {
                    // "+ Ketik Nama Model Baru": kembalikan pilihan lama dulu, lalu tampilkan kotak isian
                    spModel.setSelection(modelList.indexOf(selectedModel).coerceAtLeast(0))
                    askNewModel()
                } else {
                    selectedModel = modelList[pos]
                    prefs.edit().putString("model", selectedModel).apply()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    /** Susun ulang daftar: model bawaan + model yang pernah diketik + tombol tambah. */
    private fun refreshModelSpinner() {
        val custom = prefs.getStringSet("custom_models", emptySet()).orEmpty().sorted()
        modelList = (builtinModels + custom.filter { it !in builtinModels }).toMutableList()
        if (selectedModel !in modelList) modelList.add(selectedModel)
        val adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, modelList + addModelLabel
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spModel.adapter = adapter
        spModel.setSelection(modelList.indexOf(selectedModel))
    }

    private fun askNewModel() {
        val input = EditText(this).apply {
            hint = "contoh: gemini-3.8-flash"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Nama model baru")
            .setMessage("Tulis nama model Gemini persis seperti di Google AI Studio (huruf kecil, tanpa spasi).")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                if (input.text.isNullOrBlank()) {
                    Toast.makeText(this, "Nama model masih kosong", Toast.LENGTH_SHORT).show()
                } else {
                    val name = GeminiClient.normalizeModel(input.text.toString())
                    val custom = prefs.getStringSet("custom_models", emptySet()).orEmpty().toMutableSet()
                    if (name !in builtinModels) custom.add(name)
                    prefs.edit().putStringSet("custom_models", custom).putString("model", name).apply()
                    selectedModel = name
                    refreshModelSpinner()
                    Toast.makeText(this, "Model dipilih: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Saran & donasi ----------

    /** Buka chat WhatsApp pembuat (08568928050) dengan pesan awal yang sudah terisi. */
    private fun openWhatsApp(message: String) {
        val url = "https://wa.me/628568928050?text=" + Uri.encode(message)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "WhatsApp/browser tidak ditemukan. Hubungi 0856-8928-050 secara manual.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun appVersion(): String = try {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }
}
