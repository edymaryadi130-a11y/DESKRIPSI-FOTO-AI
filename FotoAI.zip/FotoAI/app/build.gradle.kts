plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.fotoai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.fotoai"
        minSdk = 26
        targetSdk = 34
        // versionCode = menit sejak 1970: tiap build otomatis lebih baru dari build sebelumnya,
        // jadi APK baru selalu bisa dipasang menimpa yang lama (tanpa hapus aplikasi).
        versionCode = (System.currentTimeMillis() / 60_000L).toInt()
        // Nomor build GitHub Actions ikut tampil di nama versi (mis. 1.1.7)
        versionName = "1.1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Tanda tangan tetap: wajib sama di semua versi supaya pembaruan bisa menimpa versi lama.
    // Jangan ganti/hapus file fotoai.keystore, kalau tidak aplikasi lama harus dihapus dulu.
    signingConfigs {
        create("fotoai") {
            storeFile = file("fotoai.keystore")
            storePassword = "fotoai123"
            keyAlias = "fotoai"
            keyPassword = "fotoai123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fotoai")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fotoai")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
